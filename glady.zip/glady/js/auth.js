// ==========================================
// 1. ОТРИМУЄМО ЕЛЕМЕНТИ З HTML
// ==========================================
const welcomeScreen = document.getElementById('welcome-screen');
const loginForm = document.getElementById('login-form');
const registerForm = document.getElementById('register-form');

const showLoginBtn = document.getElementById('show-login-btn');
const showRegisterBtn = document.getElementById('show-register-btn');

// Поля вводу (щоб ми могли на них вішати події)
const loginInput = document.getElementById('login-user');
const passInput = document.getElementById('login-pass');
const regEmailInput = document.getElementById('reg-email');
const regLoginInput = document.getElementById('reg-login');
const regPassInput = document.getElementById('reg-pass');
const regConfirmInput = document.getElementById('reg-confirm');

// Усі поля разом (для легкого очищення)
const allInputs = [loginInput, passInput, regEmailInput, regLoginInput, regPassInput, regConfirmInput];

// ==========================================
// 2. ДОДАТКОВА МАГІЯ (Чистота і порядок)
// ==========================================

// Функція "Прибиральниця": чистить текст і прибирає червоні рамки
function clearAllFields() {
    allInputs.forEach(input => {
        input.value = ""; // Стираємо написане
        input.style.border = "1px solid #ccc"; // Повертаємо сіру рамку
        input.style.backgroundColor = "white"; // Повертаємо білий фон
    });
}

// 🔥 ЛАЙФХАК: Як тільки ти починаєш писати в полі — червона рамка зникає
allInputs.forEach(input => {
    input.addEventListener('input', () => {
        input.style.border = "1px solid #ccc";
        input.style.backgroundColor = "white";
    });
});

// ==========================================
// 3. ПЕРЕМИКАННЯ МІЖ ЕКРАНАМИ
// ==========================================

// Показати початковий екран
function showWelcome() {
    clearAllFields(); // Чистимо все перед показом
    welcomeScreen.classList.remove('hidden');
    loginForm.classList.add('hidden');
    registerForm.classList.add('hidden');
}

// Клік на "Log in"
showLoginBtn.addEventListener('click', () => {
    clearAllFields(); // Чистимо старі помилки і текст
    welcomeScreen.classList.add('hidden');
    loginForm.classList.remove('hidden');
    registerForm.classList.add('hidden');
});

// Клік на "Sign up"
showRegisterBtn.addEventListener('click', () => {
    clearAllFields(); // Чистимо старі помилки і текст
    welcomeScreen.classList.add('hidden');
    loginForm.classList.add('hidden');
    registerForm.classList.remove('hidden');
});

// ==========================================
// 4. ФУНКЦІЯ РЕЄСТРАЦІЇ
// ==========================================
function validateAndRegister() {
    const emailOrPhone = regEmailInput.value.trim();
    const login = regLoginInput.value.trim();
    const password = regPassInput.value;
    const confirm = regConfirmInput.value;

    // Скидаємо помилки перед перевіркою
    resetErrors([regEmailInput, regLoginInput, regPassInput, regConfirmInput]);

    let isValid = true;
    let errorMessage = "";

    if (!emailOrPhone || !login || !password || !confirm) {
        alert("Будь ласка, заповніть усі поля!");
        return; 
    }

    // Перевірка пошти/телефону
    if (emailOrPhone.includes('@')) {
        const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!emailPattern.test(emailOrPhone)) {
            showError(regEmailInput);
            errorMessage += "- Невірний формат Email\n";
            isValid = false;
        }
    } else {
        const phonePattern = /^\d+$/; 
        if (!phonePattern.test(emailOrPhone)) {
            showError(regEmailInput);
            errorMessage += "- Телефон має містити тільки цифри\n";
            isValid = false;
        } else if (emailOrPhone.length < 10) {
            showError(regEmailInput);
            errorMessage += "- Номер телефону надто короткий\n";
            isValid = false;
        }
    }

    if (password !== confirm) {
        showError(regPassInput);
        showError(regConfirmInput);
        errorMessage += "- Паролі не співпадають\n";
        isValid = false;
    }

    if (isValid) {
        localStorage.setItem('storedLogin', login);
        localStorage.setItem('storedPassword', password);

        alert("Реєстрація успішна! Тепер увійдіть.");
        
        // Переходимо на вхід, але спочатку все чистимо
        clearAllFields(); 
        
        welcomeScreen.classList.add('hidden');
        registerForm.classList.add('hidden');
        loginForm.classList.remove('hidden'); 
    } else {
        alert("Виправте помилки:\n" + errorMessage);
    }
}

// ==========================================
// 5. ФУНКЦІЯ ВХОДУ
// ==========================================
function handleLogin() {
    const enteredLogin = loginInput.value.trim();
    const enteredPass = passInput.value.trim();

    const trueLogin = localStorage.getItem('storedLogin');
    const truePass = localStorage.getItem('storedPassword');

    // Скидаємо помилки перед перевіркою
    resetErrors([loginInput, passInput]);

    if (!enteredLogin || !enteredPass) {
        alert("Введіть логін та пароль!");
        return;
    }

    if ((enteredLogin === trueLogin && enteredPass === truePass) || (enteredLogin === "admin" && enteredPass === "admin")) {
        window.location.href = "main.html"; 
    } else {
        alert("Невірний логін або пароль!");
        showError(loginInput);
        showError(passInput);
    }
}

// ==========================================
// 6. ДОПОМІЖНІ ФУНКЦІЇ
// ==========================================
function showError(element) {
    element.style.border = "2px solid red";
    element.style.backgroundColor = "#ffe6e6";
}

function resetErrors(elements) {
    elements.forEach(el => {
        el.style.border = "1px solid #ccc";
        el.style.backgroundColor = "white";
    });
}