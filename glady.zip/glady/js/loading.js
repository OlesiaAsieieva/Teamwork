let progress = 0;
const progressBar = document.getElementById("progressBar");

// швидкість (менше число = швидше)
const speed = 30;

const loading = setInterval(() => {
    progress += 1;
    progressBar.style.width = progress + "%";

    if (progress >= 100) {
        clearInterval(loading);

        // невелика пауза для краси
        setTimeout(() => {
            window.location.href = "login.html";
        }, 500);
    }
}, speed);
